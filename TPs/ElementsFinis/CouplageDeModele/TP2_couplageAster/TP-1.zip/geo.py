#!/usr/bin/env python

###
### This file is generated automatically by SALOME v9.4.0 with dump python functionality
###

import sys
import salome

salome.salome_init()
import salome_notebook
notebook = salome_notebook.NoteBook()
sys.path.insert(0, r'/home-local/poumaziz/INSA/Enseignement/Couplage-GMM')

###
### GEOM component
###

import GEOM
from salome.geom import geomBuilder
import math
import SALOMEDS


geompy = geomBuilder.New()

O = geompy.MakeVertex(0, 0, 0)
OX = geompy.MakeVectorDXDYDZ(1, 0, 0)
OY = geompy.MakeVectorDXDYDZ(0, 1, 0)
OZ = geompy.MakeVectorDXDYDZ(0, 0, 1)
Face_1 = geompy.MakeFaceHW(200, 100, 1)
geompy.TranslateDXDYDZ(Face_1, 100, 50, 0)
Disk_1 = geompy.MakeDiskR(25, 1)
Cut_1 = geompy.MakeCutList(Face_1, [Disk_1], True)
[Edge_1,Edge_2,Edge_3,Edge_4,Edge_5] = geompy.ExtractShapes(Cut_1, geompy.ShapeType["EDGE"], True)
geompy.addToStudy( O, 'O' )
geompy.addToStudy( OX, 'OX' )
geompy.addToStudy( OY, 'OY' )
geompy.addToStudy( OZ, 'OZ' )
geompy.addToStudy( Face_1, 'Face_1' )
geompy.addToStudy( Disk_1, 'Disk_1' )
geompy.addToStudy( Cut_1, 'Cut_1' )
geompy.addToStudyInFather( Cut_1, Edge_1, 'Edge_1' )
geompy.addToStudyInFather( Cut_1, Edge_2, 'Edge_2' )
geompy.addToStudyInFather( Cut_1, Edge_3, 'Edge_3' )
geompy.addToStudyInFather( Cut_1, Edge_4, 'Edge_4' )
geompy.addToStudyInFather( Cut_1, Edge_5, 'Edge_5' )


if salome.sg.hasDesktop():
  salome.sg.updateObjBrowser()
